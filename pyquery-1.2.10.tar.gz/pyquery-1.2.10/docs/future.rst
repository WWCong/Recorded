Future
-------

- SELECTORS: done

- ATTRIBUTES: done

- CSS: done

- HTML: done

- MANIPULATING: missing the wrapInner method

- TRAVERSING: about half done

- EVENTS: nothing to do with server side might be used later for automatic ajax

- CORE UI EFFECTS: did hide and show the rest doesn't really makes sense on
  server side

- AJAX: some with wsgi app

